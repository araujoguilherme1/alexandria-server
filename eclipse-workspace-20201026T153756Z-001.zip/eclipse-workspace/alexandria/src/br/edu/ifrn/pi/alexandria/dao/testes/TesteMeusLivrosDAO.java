package br.edu.ifrn.pi.alexandria.dao.testes;

import java.util.List;

import br.edu.ifrn.pi.alexandria.dao.MeusLivrosDAO;
import br.edu.ifrn.pi.alexandria.dominio.MeusLivros;
import br.edu.ifrn.pi.alexandria.dominio.Usuario;

public class TesteMeusLivrosDAO {

	public static void main(String[] args) {
		
		MeusLivrosDAO dao = new MeusLivrosDAO();
		
		
		MeusLivros livro = new MeusLivros("123456789", "pavilalouyse", "20190813103000");
		MeusLivros livro2 = new MeusLivros("123459876", "guilhermearaujo", "20190413092500");
		
		dao.inserir(livro);
		dao.inserir(livro2);
		
		Usuario user = new Usuario();
		MeusLivros data = new MeusLivros();
		
		dao.remover("123456789");
		
		dao.atualizar(livro, user, data);
		
		MeusLivros mls = dao.buscarMeusLivros(livro.getCodigo(), user.getLogin(), data.getData());
		
		
		System.out.println(mls.getCodigo());
		System.out.println(mls.getLogin());
		System.out.println(mls.getData());

		List<MeusLivros> livros = dao.buscarMeusLivros(livro.getCodigo(), user.getLogin());
		
		System.out.println(livros.get(0).getCodigo());

	}

}

