package br.edu.ifrn.pi.alexandria.dao.testes;

import java.util.List;

import br.edu.ifrn.pi.alexandria.dao.LivroDAO;
import br.edu.ifrn.pi.alexandria.dominio.Livro;

public class TesteLivroDAO {

	public static void main(String[] args) {
		
		LivroDAO dao = new LivroDAO();
		
		
		Livro livro = new Livro("", 2, "Suzana Collins", "Jogos Vorazes", "123456789");
		Livro livro2 = new Livro("", 3, "Edgar Poe", "O gato preto", "123459876");
		Livro livro3 = new Livro("", 1, "Clarisse Lispector", "A hora da estrela", "46756789");
		Livro livro4 = new Livro("", 2, "Veronica Roth", "Divergente", "5899321");
		Livro livro5 = new Livro("", 13, "James Bowen", "Um gato de rua chamado Bob", "7581462");
		Livro livro6 = new Livro("", 7, "Gayle Forman", "Se eu ficar", "456321987");
		Livro livro7 = new Livro("", 1, "John Green", "A culpa é das estrelas", "58214123");
		Livro livro8 = new Livro("", 1, "Machado de Assis", "Dom Casmurro", "36625414");
		Livro livro9 = new Livro("", 15, "Conceição Evaristo", "Olhos d'água", "258963147");
		Livro livro10 = new Livro("", 7, "Nicholas Sparks", "A última música", "59631597");
		
		dao.inserir(livro);
		dao.inserir(livro2);
		dao.inserir(livro3);
		dao.inserir(livro4);
		dao.inserir(livro5);
		dao.inserir(livro6);
		dao.inserir(livro7);
		dao.inserir(livro8);
		dao.inserir(livro9);
		dao.inserir(livro10);
		
		
		// dao.remover("123456789");
		
		dao.atualizar(livro2);
		
		Livro l = dao.buscarLivro(livro.getCodigo());
		
		
		System.out.println(l.getTitulo());
		System.out.println(l.getAutor());
		
		List<Livro> livros = dao.buscarLivros();
		
		System.out.println(livros.get(0).getGenero());

	}

}
