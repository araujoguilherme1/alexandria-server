package br.edu.ifrn.pi.alexandria.dominio;

public class MeusLivros {
	
	private String codigo;
	private String login;
	private String data;
	
	public MeusLivros() {
		
	}
	
	public MeusLivros(String codigo, String login, String data) {
		this.codigo = codigo;
		this.login = login;
		this.data = data;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getLogin() {
		return login;
	}
	
	public void setData(String data) {
		this.data = data;	
	}
	
	public String getData() {
		return data;
	}
}
