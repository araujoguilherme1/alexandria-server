package br.edu.ifrn.pi.alexandria.dao.testes;

import java.util.List;

import br.edu.ifrn.pi.alexandria.dao.UsuarioDAO;
import br.edu.ifrn.pi.alexandria.dominio.Usuario;

public class TesteUsuarioDAO {


	public static void main(String[] args) {
		
		UsuarioDAO dao = new UsuarioDAO();
		
		
		Usuario usuario = new Usuario("Guilherme", "guilhermearaujo", "araujoguilherme@gmail.com", "1234", "Santa Cruz", "Estudante de Informática", "84996069155", "");
		Usuario usuario2 = new Usuario("Pavila", "pavilalouyse", "pavilalouyse@gmail.com", "4321", "Santa Cruz", "Estudante de Informática, apaixonada por romances", "84999597339", "");
		Usuario usuario3 = new Usuario("Danilo", "carlosdanilo", "carlosdanilo@gmail.com", "12345", "Tangara", "Poeta", "84999469791", "");
		Usuario usuario4 = new Usuario("Nathália", "nahbps", "nahbps@gmail.com", "6789", "Santa Cruz", "Estudante de Informática", "84996891425", "");
		Usuario usuario5 = new Usuario("Clemerson Lucas", "lucasclemerson", "clemerson@gmail.com", "cle123", "Campo Redondo", "Vaqueiro", "84887251639", "");
		Usuario usuario6 = new Usuario("Laysi Araujo", "laysiaraujo", "laysiaraujo@gmail.com", "laysi321", "Natal", "Professora de Espanhol no IFRN.", "84996258912", "");
		Usuario usuario7 = new Usuario("Daniel", "danielsantos", "daniel@gmail.com", "5826", "Natal", "Professor de Programação", "84991254897", "");
		Usuario usuario8 = new Usuario("Nathália", "nahbps", "nahbps@gmail.com", "6789", "Santa Cruz", "Estudante de Informática", "84996891425", "");
		Usuario usuario9 = new Usuario("Isaque Barbosa", "agatha", "agatha@gmail.com", "45698", "Santa Cruz", "Modelo, CrossFiteiro", "84999991819", "");
		Usuario usuario10 = new Usuario("Ana Alice", "anaalice", "anaalice123@gmail.com", "anaalice12", "Campo Redondo", "", "84999521456", "");
		
		dao.inserir(usuario);
		dao.inserir(usuario2);
		dao.inserir(usuario3);
		dao.inserir(usuario4);
		dao.inserir(usuario5);
		dao.inserir(usuario6);
		dao.inserir(usuario7);
		dao.inserir(usuario8);
		dao.inserir(usuario9);
		dao.inserir(usuario10);
		
		dao.remover("carlosdanilo");
		
		dao.atualizar(usuario3);
		
		Usuario u = dao.buscarUsuario(usuario.getLogin());
		
		
		System.out.println(u.getNome());
		
		List<Usuario> usuarioArray = dao.buscarUsuarios(usuario.getLogin());
		
		System.out.println(usuarioArray.get(0).getCidade());

	}

}