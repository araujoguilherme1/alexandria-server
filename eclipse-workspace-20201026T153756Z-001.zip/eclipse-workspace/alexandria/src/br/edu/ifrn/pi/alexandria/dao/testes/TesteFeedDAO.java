package br.edu.ifrn.pi.alexandria.dao.testes;

import br.edu.ifrn.pi.alexandria.dao.FeedDAO;
import br.edu.ifrn.pi.alexandria.dominio.Feed;

public class TesteFeedDAO {
	public static void main(String[] args) {
		FeedDAO dao = new FeedDAO();
		
		Feed feed = new Feed("2019-09-10", "livro bom!", "1", "laysiaraujo", "123456789");
		Feed feed1 = new Feed("2019-08-11", "incr[ivel", "2", "pavilalouyse", "123459876");
		Feed feed2 = new Feed("2019-04-13", "eu gostei muito desse livro!", "3", "carlosdanilo", "46756789");
		Feed feed3 = new Feed("2019-01-14", "tudo de bom essa leitura", "4", "guilhermearaujo", "258963147");
		Feed feed4 = new Feed("2019-12-01", "amei!!!", "5", "nahbps", "59631597");
		
		dao.inserir(feed);
		dao.inserir(feed1);
		dao.inserir(feed2);
		dao.inserir(feed3);
		dao.inserir(feed4);
		
		dao.atualizar(feed);
		dao.atualizar(feed1);
	}
}
