package br.edu.ifrn.pi.alexandria.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifrn.pi.alexandria.dominio.Usuario;
import br.edu.ifrn.pi.alexandria.dominio.Livro;
import br.edu.ifrn.pi.alexandria.dominio.MeusLivros;

public class MeusLivrosDAO {

		public boolean inserir(MeusLivros meuLivro){

			boolean resultado = false;
			String inserir = "INSERT INTO MeusLivros(codigo, login, data) VALUES(?,?,?)";


			Connection con = Conexao.conectar();

			try {

				PreparedStatement comando = con.prepareStatement(inserir);

				comando.setString(1, meuLivro.getCodigo());
				comando.setString(2, meuLivro.getLogin());
				comando.setString(3, meuLivro.getData());
				
				comando.execute();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			finally {
				Conexao.desconectar();
			}


			return resultado;
		} 


		public boolean remover(String codigo){

			boolean resultado = false;
			String remover = "DELETE FROM Livro WHERE codigo = ?";


			Connection con = Conexao.conectar();

			try {

				PreparedStatement comando = con.prepareStatement(remover);

				comando.setString(1, codigo); 

				comando.execute();
				
			} catch (SQLException e) {

				e.printStackTrace();
			}

			finally {
				Conexao.desconectar();
			}


			return resultado;
		} 


		public boolean atualizar(MeusLivros livro, Usuario usuario, MeusLivros data){

			boolean resultado = false;

			String atualizar = "UPDATE Livro set codigo = ?, login = ?, data = ?" + "WHERE codigo = ?";


			Connection con = Conexao.conectar();

			try {

				PreparedStatement comando = con.prepareStatement(atualizar);

				comando.setString(1, livro.getCodigo());
				comando.setString(2, usuario.getLogin());
				comando.setString(3, data.getData());
				
				comando.execute();

			} catch (SQLException e) {

				e.printStackTrace();
			}

			finally {
				Conexao.desconectar();
			}


			return resultado;
		}


		public MeusLivros buscarMeusLivros(String codigo, String login, String data) {	

			MeusLivros mls = null;   

			String queryInserir = "SELECT codigo, login, data FROM MeusLivros WHERE codigo = ?, login = ?";


			Connection con = Conexao.conectar();

			try {


				PreparedStatement comando = con.prepareStatement(queryInserir);
				comando.setString(1, codigo);
				comando.setString(2, login);

				ResultSet rSet = comando.executeQuery();

				if(rSet.next()){
					mls = new MeusLivros();
	                
					mls.setCodigo(rSet.getString("codigo"));
					mls.setLogin(rSet.getString("login"));
					mls.setData(rSet.getString("data"));
					
				}

			} catch (SQLException e) {

				e.printStackTrace();
			}

			finally {
				Conexao.desconectar();
			}

			return mls;
		}

		
		public List<MeusLivros> buscarMeusLivros(String codigo, String login) {

			ArrayList<MeusLivros> lista = new  ArrayList<MeusLivros>();

			String queryInserir = "SELECT codigo, login, data FROM MeusLivros WHERE codigo = ?, login = ?";
					
	         System.out.println(codigo);

			Connection con = Conexao.conectar();

			try {

				PreparedStatement comando = con.prepareStatement(queryInserir);
				comando.setString(1, codigo);
				comando.setString(2, login);
				ResultSet rSet = comando.executeQuery();

				while(rSet.next()){


					MeusLivros mls = new MeusLivros();
					
					mls.setCodigo(rSet.getString("codigo"));
					mls.setLogin(rSet.getString("login"));
					mls.setData(rSet.getString("data"));

					lista.add(mls);

				}

			} catch (SQLException e) {

				e.printStackTrace();
			}

			finally {
				Conexao.desconectar();
			}

			return lista;
		} 
	}

