package br.edu.ifrn.pi.alexandria.dominio;

import java.util.ArrayList;

public class Genero {
	
	public Genero() {
		
	}
	
	public Genero(String descricao, String id) {
		this.descricao = descricao;
		this.id = id;
	}
	
	private String descricao;
	private String id;
	
	public void setDescricao(String desc) {
		descricao = desc;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getId() {
		return id;
	}
}
