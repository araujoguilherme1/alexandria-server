package br.edu.ifrn.pi.alexandria.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifrn.pi.alexandria.dominio.Usuario;
import br.edu.ifrn.pi.alexandria.dominio.Livro;

public class LivroDAO {

	public boolean inserir(Livro livro){

		boolean resultado = false;
		String inserir = "INSERT INTO livro(foto, genero_id, autor, titulo, codigo) VALUES(?,?,?,?,?)";


		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(inserir);

			comando.setString(1, livro.getFoto());
			comando.setInt(2, livro.getGenero());
			comando.setString(3, livro.getAutor());
			comando.setString(4, livro.getTitulo());
			comando.setString(5, livro.getCodigo());
		
			comando.execute();
			resultado = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	} 


	public boolean remover(String codigo){

		boolean resultado = false;
		String remover = "DELETE FROM livro WHERE codigo = ?";


		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(remover);

			comando.setString(1, codigo); 

			comando.execute();
			resultado = true;
			
		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	} 


	public boolean atualizar(Livro livro){

		boolean resultado = false;

		String atualizar = "UPDATE livro set foto = ?, genero_id = ?, autor = ?, titulo = ? "
				+ "WHERE codigo = ?";


		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(atualizar);

			comando.setString(1, livro.getFoto());
			comando.setInt(2, livro.getGenero());
			comando.setString(3, livro.getAutor());
			comando.setString(4, livro.getTitulo());
			comando.setString(5, livro.getCodigo());
			
			comando.execute();
			return true;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	}


	public Livro buscarLivro(String codigo) {	

		Livro livro1 = null;   

		String queryInserir = "SELECT foto, genero_id, autor, titulo FROM livro WHERE codigo = ?";


		Connection con = Conexao.conectar();

		try {


			PreparedStatement comando = con.prepareStatement(queryInserir);
			comando.setString(1, codigo);

			ResultSet rSet = comando.executeQuery();

			if(rSet.next()){
				livro1 = new Livro();
				
				livro1.setFoto(rSet.getString("foto"));
				livro1.setGenero(rSet.getInt("genero_id"));
				livro1.setAutor(rSet.getString("autor"));
				livro1.setTitulo(rSet.getString("titulo"));
				livro1.setCodigo(codigo);
				
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return livro1;
	}


	
	public List<Livro> buscarLivros() {

		ArrayList<Livro> lista = new  ArrayList<Livro>();

		String queryInserir = "SELECT codigo, foto, genero_id, autor, titulo FROM livro;";
				
        

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(queryInserir);
			
			ResultSet rSet = comando.executeQuery();

			while(rSet.next()){


				Livro l2 = new Livro();
				
				l2.setFoto(rSet.getString("foto"));
				l2.setGenero(rSet.getInt("genero_id"));
				l2.setAutor(rSet.getString("autor"));
				l2.setTitulo(rSet.getString("titulo"));
				l2.setCodigo(rSet.getString("codigo"));
				
				lista.add(l2);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return lista;
	} 
}