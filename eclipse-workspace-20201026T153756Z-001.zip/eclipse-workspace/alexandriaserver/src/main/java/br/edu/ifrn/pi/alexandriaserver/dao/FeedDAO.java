package br.edu.ifrn.pi.alexandriaserver.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifrn.pi.alexandriaserver.dao.Conexao;
import br.edu.ifrn.pi.alexandriaserver.dominio.Feed;
import br.edu.ifrn.pi.alexandriaserver.dominio.Usuario;

public class FeedDAO {

	public boolean inserir(Feed feed){

		boolean resultado = false;
		String inserir = "INSERT INTO feed(data, resenha, id, loginUsuario, codigoLivro) VALUES(?,?,?,?,?)";


		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(inserir);

			comando.setString(1, feed.getData());
			comando.setString(2, feed.getResenha());
			comando.setString(3, feed.getId());
			comando.setString(4, feed.getLoginUsuario());
			comando.setString(5, feed.getCodigoLivro());

			comando.execute();
			resultado = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return resultado;
	}
	
//<<------------------------------------------------------------------------------------------->>
	
	public boolean remover(String id){

		boolean resultado = false;
		String remover = "DELETE FROM feed WHERE id = ?";

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(remover);

			comando.setString(1, id); 

			comando.execute();
			resultado = true;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return resultado;
	} 

//<<------------------------------------------------------------------------------------------->>

	public boolean atualizar(Feed feed){

		boolean resultado = false;

		String atualizar = "UPDATE Feed set fata = ?, resenha = ?, id = ?, loginUsuario = ?, codigoLivro = ?";

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(atualizar);

			comando.setString(1, feed.getData());
			comando.setString(2, feed.getResenha());
			comando.setString(3, feed.getId());
			comando.setString(4, feed.getLoginUsuario());
			comando.setString(5, feed.getCodigoLivro());
			
			comando.execute();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return resultado;
	}
	
//<<------------------------------------------------------------------------------------------->>
	public Feed buscarFeed(String id) {	

		Feed feed = null;   

		String queryInserir = "SELECT data, resenha,loginUsuario, codigoLivro titulo FROM feed WHERE id= ?";


		Connection con = Conexao.conectar();

		try {


			PreparedStatement comando = con.prepareStatement(queryInserir);
			comando.setString(1, id);

			ResultSet rSet = comando.executeQuery();

			if(rSet.next()){
				feed = new Feed();
				
				feed.setData(rSet.getString("data"));
				feed.setResenha(rSet.getString("resenha"));
				feed.setLoginUsuario(rSet.getString("login usuario"));
				feed.setCodigoLivro(rSet.getString("codigo livro"));
				feed.setId(id);
				
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return feed;
	}
	//<<------------------------------------------------------------------------------------------->>

	public List<Feed> buscarFeed() {

		ArrayList<Feed> lista = new  ArrayList<Feed>();

		String queryInserir = "SELECT data, resenha,loginUsuario, codigoLivro titulo FROM feed;";
				
        

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(queryInserir);
			
			ResultSet rSet = comando.executeQuery();

			while(rSet.next()){


				Feed feed2 = new Feed();
				
				feed2.setData(rSet.getString("data"));
				feed2.setResenha(rSet.getString("resenha"));
				feed2.setLoginUsuario(rSet.getString("login usuario"));
				feed2.setCodigoLivro(rSet.getString("codigo livro"));
				feed2.setId(rSet.getString("id"));
				
				lista.add(feed2);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return lista;
	}
}