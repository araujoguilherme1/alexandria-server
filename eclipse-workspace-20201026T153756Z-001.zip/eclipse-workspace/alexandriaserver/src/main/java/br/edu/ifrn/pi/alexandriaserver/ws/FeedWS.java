package br.edu.ifrn.pi.alexandriaserver.ws;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.edu.ifrn.pi.alexandriaserver.dao.FeedDAO;
import br.edu.ifrn.pi.alexandriaserver.dominio.Feed;

public class FeedWS {

	@GET  //Buscar todos os livros
	@Produces(MediaType.APPLICATION_JSON)
	public List<Feed> buscarFeed() {
		FeedDAO dao = new FeedDAO();
		return dao.buscarFeed();
		
	}
	
	@GET //Busca individual dos livros
	@Path ("/{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Feed buscarFeed(@PathParam("id") String id) {
	
		FeedDAO dao = new FeedDAO();
		return dao.buscarFeed(id);
	}

	@POST 
	@Path ("inserir")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean inserirFeed(Feed feed){	
		FeedDAO dao = new FeedDAO();
		return dao.inserir(feed);
	}
	
	@PUT //Atualiza informações de um livro
	@Path ("atualizar")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean atualizar (Feed feed){ 
		FeedDAO dao = new FeedDAO();
		return dao.atualizar(feed);
	}	
	
	@DELETE //Apaga publicação/livro
	@Path("remover/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean remover(@PathParam("id)") long id){	
		System.out.println("Remover");
		FeedDAO dao = new FeedDAO();
		String codi = String.valueOf(id);
		return dao.remover(codi);
	}

	
}
