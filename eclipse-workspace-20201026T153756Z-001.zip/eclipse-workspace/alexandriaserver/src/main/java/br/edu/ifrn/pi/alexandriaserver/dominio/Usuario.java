package br.edu.ifrn.pi.alexandriaserver.dominio;

import java.util.Scanner;
import java.util.ArrayList;

public class Usuario {
	private ArrayList<Livro> possui;
	private ArrayList<Livro> troca;
	
	private String nome;
	private String login;
	private String email;
	private String senha;
	private String cidade;
	private String biografia;
	private String telefone;
	private String foto;

	public Usuario() {
		
	}
	public Usuario(String nome, String login, String email, String senha, String cidade, String biografia, String telefone, String foto) {
		this.nome = nome;
		this.login = login;
		this.email = email;
		this.senha = senha;
		this.cidade = cidade;
		this.biografia = biografia;
		this.telefone = telefone;
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getBiografia() {
		return biografia;
	}
	public void setBiografia(String biografia) {
		this.biografia = biografia;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
}