package br.edu.ifrn.pi.alexandriaserver.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifrn.pi.alexandriaserver.dominio.Usuario;
import br.edu.ifrn.pi.alexandriaserver.dao.Conexao;

public class UsuarioDAO {

	public boolean inserir(Usuario usuario){

		boolean resultado = false;
		String inserir = "INSERT INTO usuario(nome, login, email, senha, cidade, biografia, telefone, foto) VALUES(?,?,?,?,?,?,?,?)";


		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(inserir);

			comando.setString(1, usuario.getNome());
			comando.setString(2, usuario.getLogin());
			comando.setString(3, usuario.getEmail());
			comando.setString(4, usuario.getSenha());
			comando.setString(5, usuario.getCidade());
			comando.setString(6, usuario.getBiografia());
			comando.setString(7, usuario.getTelefone());	
			comando.setString(8, usuario.getFoto());

			comando.execute();
			resultado = true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	} 

	public boolean remover(String login){

		boolean resultado = false;
		String remover = "DELETE FROM Usuario WHERE login = ?";

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(remover);

			comando.setString(1, login); 

			comando.execute();
			resultado = true;

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	} 



	public boolean atualizar(Usuario usuario){

		boolean resultado = false;

		String atualizar = "UPDATE Usuario set nome = ?, login = ?, email = ?, senha = ?, cidade = ?, biografia = ?, telefone = ?, foto = ?"
				+ "WHERE login = ?";

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(atualizar);

			comando.setString(1, usuario.getNome());
			comando.setString(2, usuario.getLogin());
			comando.setString(3, usuario.getEmail());
			comando.setString(4, usuario.getSenha());
			comando.setString(5, usuario.getCidade());
			comando.setString(6, usuario.getBiografia());
			comando.setString(7, usuario.getTelefone());	
			comando.setString(8, usuario.getFoto());

			comando.execute();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}


		return resultado;
	}


	public Usuario buscarUsuario(String login) {	

		Usuario usuario1 = null;   

		String queryInserir = "SELECT nome, login, email, senha, cidade, biografia, telefone, foto FROM Usuario WHERE login = ?" ;

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(queryInserir);
			comando.setString(1, login);

			ResultSet rSet = comando.executeQuery();

			if(rSet.next()){
				usuario1 = new Usuario();

				usuario1.setNome(rSet.getString("nome"));
				usuario1.setLogin(rSet.getString("login"));
				usuario1.setEmail(rSet.getString("email"));
				usuario1.setSenha(rSet.getString("senha"));
				usuario1.setCidade(rSet.getString("cidade"));
				usuario1.setBiografia(rSet.getString("biografia"));
				usuario1.setTelefone(rSet.getString("telefone"));
				usuario1.setFoto(rSet.getString("foto"));

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return usuario1;
	}


	public List<Usuario> buscarUsuarios(String login) {

		ArrayList<Usuario> lista = new  ArrayList<Usuario>();

		String queryInserir = "select nome, login, email, senha, cidade, biografia, telefone, foto from Usuario WHERE login = ?" ;

		System.out.println(login);

		Connection con = Conexao.conectar();

		try {

			PreparedStatement comando = con.prepareStatement(queryInserir);
			comando.setString(1, login);
			ResultSet rSet = comando.executeQuery();

			while(rSet.next()){

				Usuario u2 = new Usuario();

				u2.setNome(rSet.getString("nome"));
				u2.setLogin(rSet.getString("login"));
				u2.setEmail(rSet.getString("email"));
				u2.setSenha(rSet.getString("senha"));
				u2.setCidade(rSet.getString("cidade"));
				u2.setBiografia(rSet.getString("biografia"));
				u2.setTelefone(rSet.getString("telefone"));
				u2.setFoto(rSet.getString("foto"));

				lista.add(u2);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			Conexao.desconectar();
		}

		return lista;
	} 

}