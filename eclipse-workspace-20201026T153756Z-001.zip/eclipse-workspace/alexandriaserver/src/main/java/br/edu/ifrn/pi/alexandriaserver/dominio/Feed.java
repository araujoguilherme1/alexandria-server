package br.edu.ifrn.pi.alexandriaserver.dominio;

public class Feed {
public Feed() {
		
	}
	
	public Feed(String data, String resenha, String id, String loginUsuario, String codigoLivro){
		this.data = data;
		this.resenha = resenha;
		this.id = id;
		this.loginUsuario = loginUsuario;
		this.codigoLivro = codigoLivro;
	}
	
	//private String codigo;
	private String data;
	private String resenha;
	//private String login;
	private String id;
	private String loginUsuario;
	private String codigoLivro;
	
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}

	public void setResenha(String resenha) {
		this.resenha = resenha;
	}
	public String getResenha() {
		return resenha;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	public String getId() {
		return id;
	}
	
	public void setLoginUsuario(String loginUsuario) {
		this.loginUsuario = loginUsuario;
	}
	public String getLoginUsuario() {
		return loginUsuario;
	}
	
	public void setCodigoLivro(String codigoLivro) {
		this.codigoLivro = codigoLivro;
	}
	public String getCodigoLivro() {
		return codigoLivro;
	}
}

