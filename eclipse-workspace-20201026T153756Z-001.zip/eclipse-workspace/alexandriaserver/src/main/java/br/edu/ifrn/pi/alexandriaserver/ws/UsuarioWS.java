package br.edu.ifrn.pi.alexandriaserver.ws;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.edu.ifrn.pi.alexandriaserver.dao.LivroDAO;
import br.edu.ifrn.pi.alexandriaserver.dao.UsuarioDAO;
import br.edu.ifrn.pi.alexandriaserver.dominio.Livro;
import br.edu.ifrn.pi.alexandriaserver.dominio.Usuario;


@Path ("usuario")
public class UsuarioWS {
	

	@GET //Busca todos os usuarios
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public List<Usuario> buscarUsuarios() {
		UsuarioDAO dao = new UsuarioDAO();
		return dao.buscarUsuarios("");
		
	}
	
	@GET //Busca individual
	@Path ("/{login}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Usuario buscarUsuario(@PathParam("login") String login) {
		UsuarioDAO dao = new UsuarioDAO();
		return dao.buscarUsuario(login);
	}

	@POST //Inserir novo usuario
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path ("inserir")
	public boolean inserirUsuario(Usuario usuario){	
		UsuarioDAO dao = new UsuarioDAO();
		return dao.inserir(usuario);
	}
	
	@PUT //Atualiza informações de usuario
	@Path ("atualizar")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public boolean atualizar (Usuario usuario){ 
		UsuarioDAO dao = new UsuarioDAO();
		return dao.atualizar(usuario);
	}
	
	@DELETE //Remover usuarios
	@Path("remover/{login}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public boolean remover(@PathParam("login)") long login) {	
		System.out.println("Remover");
		UsuarioDAO dao = new UsuarioDAO();
		String cod = String.valueOf(login);
		return dao.remover(cod);
	}

	
}
	