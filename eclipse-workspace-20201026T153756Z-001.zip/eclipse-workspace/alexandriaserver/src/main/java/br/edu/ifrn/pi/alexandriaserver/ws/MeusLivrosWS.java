package br.edu.ifrn.pi.alexandriaserver.ws;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.edu.ifrn.pi.alexandriaserver.dao.LivroDAO;
import br.edu.ifrn.pi.alexandriaserver.dao.MeusLivrosDAO;
import br.edu.ifrn.pi.alexandriaserver.dao.UsuarioDAO;
import br.edu.ifrn.pi.alexandriaserver.dominio.Livro;
import br.edu.ifrn.pi.alexandriaserver.dominio.MeusLivros;
import br.edu.ifrn.pi.alexandriaserver.dominio.Reacao;
import br.edu.ifrn.pi.alexandriaserver.dominio.Usuario;

@Path ("meus-livros")
public class MeusLivrosWS {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<MeusLivros> buscarMeusLivros() {
		MeusLivrosDAO dao = new MeusLivrosDAO();
		return dao.buscarMeusLivros("","");	
	}
	
	@GET
	@Path ("/{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public MeusLivros buscarMeusLivros(@PathParam("codigo") String codigo) {
		MeusLivrosDAO dao = new MeusLivrosDAO();
		return dao.buscarMeusLivros(codigo, "", "");
	}

	@POST
	@Path ("inserir")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean inserirLivro(MeusLivros livro){	
		MeusLivrosDAO dao = new MeusLivrosDAO();
		return dao.inserir(livro);
	}
	
	@DELETE
	@Path("remover")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean remover(@PathParam("codigo)") long codigo) {	
		System.out.println("Remover");
		MeusLivrosDAO dao = new MeusLivrosDAO();
		String cod = String.valueOf(codigo);
		return dao.remover(cod);
	}

	
}
	


