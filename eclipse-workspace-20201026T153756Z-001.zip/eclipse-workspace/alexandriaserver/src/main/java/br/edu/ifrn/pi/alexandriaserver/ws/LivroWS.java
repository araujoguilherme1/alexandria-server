package br.edu.ifrn.pi.alexandriaserver.ws;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.edu.ifrn.pi.alexandriaserver.dao.LivroDAO;
import br.edu.ifrn.pi.alexandriaserver.dominio.Livro;


@Path ("livros")
public class LivroWS {
	

	@GET  //Buscar todos os livros
	@Produces(MediaType.APPLICATION_JSON)
	public List<Livro> buscarLivros() {
		LivroDAO dao = new LivroDAO();
		return dao.buscarLivros();
		
	}
	
	@GET //Busca individual dos livros
	@Path ("/{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Livro buscarLivro(@PathParam("codigo") String codigo) {
	
		LivroDAO dao = new LivroDAO();
		return dao.buscarLivro(codigo);
	}

	@POST 
	@Path ("inserir")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean inserirLivro(Livro livro){	
		LivroDAO dao = new LivroDAO();
		return dao.inserir(livro);
	}
	
	@PUT //Atualiza informações de um livro
	@Path ("atualizar")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean atualizar (Livro livro){ 
		LivroDAO dao = new LivroDAO();
		return dao.atualizar(livro);
	}	
	
	@DELETE //Apaga publicação/livro
	@Path("remover/{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public boolean remover(@PathParam("codigoID)") long codigo){	
		System.out.println("Remover");
		LivroDAO dao = new LivroDAO();
		String cod = String.valueOf(codigo);
		return dao.remover(cod);
	}

	
}
	


