/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifrn.pi.alexandriaserver.dominio;
import java.util.Scanner;
import java.util.ArrayList;


public class Livro {
	
	private String foto;
	private int genero;
	private String autor;
	private String titulo;
	private String codigo;

	public Livro() {

	}
	public Livro (String foto, int genero, String autor, String titulo, String codigo) {
		this.foto = foto;
		this.genero = genero;
		this.autor = autor;
		this.titulo = titulo;
		this.codigo = codigo;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public int getGenero() {
		return genero;
	}
	
	public void setGenero(int genero) {
		this.genero = genero;
	}
}